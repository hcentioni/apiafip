const axios = require('axios');
const xmlBuilder = require('xmlbuilder');
require('dotenv').config();
const { obtenerTokenYSign } = require('./wwsaService');

const {
    CUIT_REPRESENTADA,
    WSFEV1_URL,
} = process.env;

/**
 * Construye la solicitud XML para el servicio FECAESolicitar.
 */
const buildXmlRequest = (token, sign, cuit, FeCabReq, FeDetReq) => {
    return xmlBuilder.create('soap:Envelope', { encoding: 'UTF-8' })
        .att('xmlns:soap', 'http://schemas.xmlsoap.org/soap/envelope/')
        .ele('soap:Header')
        .ele('Auth', { xmlns: 'http://ar.gov.afip.dif.FEV1/' })
        .ele('Token').text(token).up()
        .ele('Sign').text(sign).up()
        .ele('Cuit').text(cuit).up()
        .up()
        .up()
        .ele('soap:Body')
        .ele('FECAESolicitar', { xmlns: 'http://ar.gov.afip.dif.FEV1/' })
        .ele('FeCAEReq')
        .ele('FeCabReq')
        .ele('CantReg').text(FeCabReq.CantReg).up()
        .ele('PtoVta').text(FeCabReq.PtoVta).up()
        .ele('CbteTipo').text(FeCabReq.CbteTipo).up()
        .up()
        .ele('FeDetReq')
        .ele('item')
        .ele('Concepto').text(FeDetReq.Concepto).up()
        .ele('DocTipo').text(FeDetReq.DocTipo).up()
        .ele('DocNro').text(FeDetReq.DocNro).up()
        .ele('CbteDesde').text(FeDetReq.CbteDesde).up()
        .ele('CbteHasta').text(FeDetReq.CbteHasta).up()
        .ele('CbteFch').text(FeDetReq.CbteFch).up()
        .ele('ImpTotal').text(FeDetReq.ImpTotal).up()
        .ele('ImpTotConc').text(FeDetReq.ImpTotConc).up()
        .ele('ImpNeto').text(FeDetReq.ImpNeto).up()
        .ele('ImpOpEx').text(FeDetReq.ImpOpEx).up()
        .ele('ImpIVA').text(FeDetReq.ImpIVA).up()
        .ele('ImpTrib').text(FeDetReq.ImpTrib).up()
        .ele('MonId').text(FeDetReq.MonId).up()
        .ele('MonCotiz').text(FeDetReq.MonCotiz).up()
        .ele('Iva')
        .ele('item')
        .ele('Id').text(FeDetReq.Iva[0].Id).up()
        .ele('BaseImp').text(FeDetReq.Iva[0].BaseImp).up()
        .ele('Importe').text(FeDetReq.Iva[0].Importe).up()
        .end({ pretty: true });
};

/**
 * Autoriza una factura utilizando el servicio FECAESolicitar.
 */
const autorizarFactura = async (FeCabReq, FeDetReq) => {
    try {
        const { token, sign } = await obtenerTokenYSign('wsfe');

        const xmlRequest = buildXmlRequest(
            token,
            sign,
            CUIT_REPRESENTADA,
            FeCabReq,
            FeDetReq[0] // Asumimos un único detalle
        );

        const response = await axios.post(WSFEV1_URL, xmlRequest, {
            headers: { 'Content-Type': 'text/xml' },
        });

        return response.data;
    } catch (error) {
        console.error('Error al autorizar la factura:', error.message);
        throw new Error('No se pudo autorizar la factura.');
    }
};

module.exports = { autorizarFactura };
